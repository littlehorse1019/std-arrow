package net.sf.cglib.proxy;

class DBean2 {
    public int getAge() {
        return 18;
    }
}
